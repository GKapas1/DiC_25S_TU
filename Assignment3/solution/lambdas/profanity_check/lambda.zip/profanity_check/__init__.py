from .profanity_check import predict, predict_prob
__version__="1.0.2"
